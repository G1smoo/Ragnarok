
<div class="m-3 mx-auto max-w-7xl rounded  shadow sm:rounded-2xl p-3">

    <div class="hero bg-base-200 ">
      <div class="hero-content text-center">
        <div class="max-w-md">
          <h1 class="text-5xl font-bold">Hello there</h1>
          <p class="py-6">
            Provident cupiditate voluptatem et in. Quaerat fugiat ut assumenda excepturi exercitationem
            quasi. In deleniti eaque aut repudiandae et a id nisi.
          </p>
        </div>
      </div>
    </div>


    <div class="flex justify-center space-x-3 mt-3">
        
        <div class="card w-full bg-base-100 card-xl shadow-sm ">
         <div class="card-body">
           <h2 class="card-title">Tildmeld spejdere</h2>
           <p>Klik her for at tildmelde dine spejdere til Ragnarok</p>
           <div class="justify-center card-actions">
            <a href="/sub/team">
                <button class="btn btn-primary btn-wide">Tildmeld spejdere</button>
            </a>
           </div>
         </div>
       </div>

        <div class="card w-full bg-base-100 card-xl shadow-sm ">
         <div class="card-body">
           <h2 class="card-title">Tildmeld dig som hjælper</h2>
           <p>Tildmeld dig som hjælper...</p>
            <div class="justify-center card-actions">
            <a href="/sub/helper">
                <button class="btn btn-primary btn-wide">Tildmeld dig som hjælper</button>
            </a>
           </div>
         </div>
       </div>
    </div>
</div>